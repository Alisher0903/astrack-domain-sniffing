// SPDX-FileCopyrightText: 2024 Shun Sakai
//
// SPDX-License-Identifier: Apache-2.0 OR MIT

module github.com/sorairolake/lzip-go

go 1.22

require (
	github.com/google/go-cmdtest v0.4.0
	github.com/ulikunitz/xz v0.5.13
)

require (
	github.com/google/go-cmp v0.7.0 // indirect
	github.com/google/renameio v0.1.0 // indirect
)
